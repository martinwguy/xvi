XVI/PM alpha 4 version, August 2x 1995
Copyright (c) 1995, Ned Konz, nedkonz@gate.net

DO NOT DISTRIBUTE THIS, OR SHARE ITS FTP LOCATION!

If you know someone who may be interested, please have them email me.

I am releasing this for testing ONLY. It is nowhere near done. Please read
this and the attached XVI.LST files before you use the editor. Anyone using
this has an obligation to give me feedback, I think. So beat up on the editor,
read FUTURE DIRECTIONS below, and report bugs and desires to me at
nedkonz@gate.net .

If you send me mail, I will notify you when future versions become available.

This is an OS/2 PM port of the public domain XVI editor, which was distantly
derived from the STEVIE editor. It has several enhancements over the vanilla
vi editor, especially its use of multiple visible buffers. See the XVI.LST
file for a description of the basic editor. I have in turn enhanced the XVI
editor for OS/2PM.

I will release the entire package, with source code, into the public domain,
just as soon as I'm finished. It will be uploaded to Hobbes and to Compuserve.

------------------ CHANGES FROM XVI.LST

XVIINIT environment variable
    The XVIINIT environment variable will have quotes stripped off it,
    if it is quoted. So you can say:
        set XVIIINIT="set ts=4 sw=4 ai"
    and have it work right.

:cd command
    The :cd command, if given with no arguments, will use your HOME environment
    variable. If an argument is given, xvipm will try to change to that
    directory. Failing that, if the argument is a relative path (that is, with
    no drive letter or leading slash), the setting of the cdpath parameter
    will be interpreted as a list of directories to try the chdir relative to.

    Remember that the command ":cd -" takes you back to your prior directory.

    If you need to find out where you are, you can type ":cd ."

CDPATH environment variable
cdpath parameter
    See the discussion of the :cd command above. This is a semicolon-separated
    list of (possibly non-absolute) directory names. It is initially read
    from the CDPATH environment variable, but is overridden by any setting
    of the cdpath parameter.

SHELL environment variable
COMSPEC environment variable
shell parameter
    The shell parameter is set from the SHELL envrironment variable,
    if set, otherwise it is set to the value of the COMSPEC environment
    variable. Of course, it can be overridden by setting the shell parameter.

shellopt parameter
    The shellopt parameter is used for invoking a non-interactive shell. By
    default this is set to "/C", which is appropriate if you have the shell
    parameter set to CMD.EXE.

    Shells started using this way (using ":!") are spawned in a window
	that must be manually closed, so you can see the output, if any.

shelliopt parameter
    The shelliopt parameter is used for invoking an interactive shell. By
    default this is set to an empty string.

	Shells started this way are spawned in a window that will close when
	the shell ends.

LINES environment variable
COLUMNS environment variable
    The initial (row/column) dimensions of the XVIPM window can be set using the
    LINES and COLUMNS environment variables. These, if set, will override the
    settings loaded from the user INI file (or 25 lines and 80 columns, if there
    are no saved settings)

ini file restoration
    A file called "XVIPM.INI" is stored initially into the program directory,
    containing the following key/value pairs:
        Rows            -- the number of rows upon last save (binary)
        Cols            -- the number of columns (binary)
        WindowPosition -- a copy of the SWP structure (binary)
        Font            -- a string, like "8.Courier"

    However, if a file by that name is found upon startup in the current
    directory, it is used instead of the one in the program directory.

ini file saving
    The settings described above are saved upon program exit, and upon changing
    the font (see below).

mouse clicking
    A mouse button 1 click on the text area of the XVIPM window will move
    the cursor to that point. If you click past the end of a line, the cursor
    will be set at the last column.

    A mouse button click on the first or last line of an XVIPM window will
    scroll by a line; a click on the status lines will update their information.

mouse dragging
    Mouse dragging can be used to scroll text (start drag in text area),
    or to resize the buffers (start drag on a status line other than the
    bottom one)

    Resizing the whole XVIPM window with a sizing border is not,
    and will not be, supported (too hard).

font dropping
    You can drop any font from a Font Palette onto the XVIPM window.
    This font setting will be saved at program exit.

colors
    There is currently a table of 10 foreground/background color combinations.
    However, only the following ones are set to anything other than background
    (usually white) on background.

    The *colour parameters provide an index into this table. If you reset the
    stcolour parameter, the status bar might not get its 3-d look. Setting the
    colour parameter to 1, 2, or 3 will cause the text area to get stripes.
    Specifically, if you set colour to 2, you will have black on white
    (probably), with gray stripes. Why you'd want this is beyond me, however.

	// foreground   background
	{ CLR_NEUTRAL, 	CLR_BACKGROUND	},	// 0 DEF_COLOUR black? on white?
	{ CLR_NEUTRAL, 	CLR_PALEGRAY 	}, 	// 1 DEF_STCOLOUR black? on palegray
	{ CLR_NEUTRAL,	CLR_BACKGROUND  },	// 2 DEF_SYSCOLOUR (not used?)
	{ CLR_RED,	    CLR_PALEGRAY	},	// 3 DEF_ROSCOLOUR
    { CLR_BACKGROUND, CLR_NEUTRAL   },  // 4 white? on black?
    { CLR_WHITE,    CLR_BLACK       },  // 5 white on black
    { CLR_YELLOW,   CLR_DARKBLUE    },  // 6 yellow on blue
    { CLR_DARKBLUE, CLR_BACKGROUND  },  // 7 blue on white?
    { CLR_YELLOW,   CLR_BLACK       },  // 8 yellow on black

    Color dropping is not yet supported. It will be soon, but I have to figure
    out how to tell XVIPM the difference between foreground and background
    color settings. Perhaps the control key?

clipboard copy
    Hitting Ctrl-Insert copies the unnamed buffer (okay, it's named @)
    onto the clipboard. So you can do a yank without specifying a buffer,
    and hit Ctrl-Insert, and it will appear as text on the clipboard.

clipboard paste
    Hitting Shift-Insert inserts the contents of the PM clipboard into
    the current buffer at the cursor location, without changing the
    current vi mode. If you're in normal vi mode, you will be returned
    to normal mode, rather than being left in insert mode. If you're already
    in insert mode, you will stay there; if you're in replace mode, the
    clipboard text will replace, just as if it had been typed.

keyboard interrupt
    Some processing can be interrupted:
        :so file
        displaying the screen (!)
    Use the BREAK key for this.
    Ctrl-C should also work.

cursor keys, etc.
    They move about. The logic is complicated; best bet is to try them.

    I couldn't figure out how to use these. Right now, if you're in INSERT
    or REPLACE mode and you hit a cursor key, it gets you out of that mode
    and moves you. The Insert key puts you back into INSERT mode from NORMAL
    mode. So you could do a full editing session without knowing any VI motion
    or commands!

menu
    There is a (probably incomplete) menu bar. Several actions are available.
    The File/Open dialog permits multiple file selection. The Save As dialog
    permits overwriting (you can select an existing file, and it does a :w!
    internally.)

    All of these menu selections are implemented by stuffing keys into the
    editor (!).

    There is a force selection that adds a '!' to most of these commands.

------------------ NOTES

multiple buffers: same file in two buffers
    This is not a difference, just a warning:
    You can use the :buffer or :split commands (or the :e command with
    autosplit mode on) to make another window. If you want to have two
    windows with a synchronized view of the same file, use ":split", rather
    than ":bu %". This may seem obvious, but it bit me. If you do a ":bu %"
    you have two (possibly different) in-memory copies of the same file.

------------------ PROBABLE BUGS / MALFEATURES

Keystroke decoding for non-ASCII keys is probably not complete.

There may well be some control-key combinations that don't work.

Shift-, Alt- arrow keys do the same thing that their non-shifted
counterparts do.

There may be half-character-wide trash left on the right side of some lines
when you change fonts. A redraw should fix this.

Changing the color using ":set colour" will not re-do the background. A
scroll will fix this.

Writing to pipelines (":w ! pipe") causes hangs most of the time;
reading from them (":r ! pipe") causes hangs some of the time. These
are implemented with _popen(). (I'm using the Borland 2.0 compiler.)

Filters seem to work OK, though (they are implemented using temp files,
and so seem to be less prone to deadlocks).

You can select too many files from the File/Open dialog. This will cause
a beep. The limit is about 1000 characters. Best bet for lots of files is to
use wildcards (these are expanded into a separate buffer).

As a consequence of the way I'm doing File/Open, the editor will let you
type in commands that go off the end of the status line. You just can't see
any characters out there, of course.

------------------ LIMITS

COLUMNS should not be set above 298.

The maximum length of an input line is 1024.

NUL characters (ASCII 0) aren't allowed in the buffers.

The (possibly stuffed) command line is limited to about 1000 characters.

------------------ FUTURE DIRECTIONS

Color dropping will be added, probably. How should this work?

I may add the ability to map non-ASCII keystrokes, so you could do
something like:
    :map #2 dw
to make the F2 key delete words. Is this important to you?

The problem with function key mapping, internally, is that the function keys
are sent to the editor engine as single-byte characters. So you couldn't have
both a full extended character set and function key mapping. If you could
live with this, it should be possible (which part of the range 0x80-0xff is
most important to you?)

If I don't send VisualAge/C++ 3.0 back to IBM, I will add Workframe DDE
support to the editor (if I can figure out DDE <g>). Would anyone else
need this?

I'm not sure how important dropping files is. Do you need this?

---------------------- Alpha 1 to Alpha 2 changes:

Changed mouse clicks to exit INSERT mode and then position.

Fixed File/Open bug with single file name.

INI file:
    Stopped using OS2.INI; now we make an INI file in the program directory.
    Upon startup, we look first for an INI file (named "xvipm.ini") in the
    current directory, then in the program directory. If we don't find any,
    we make a new one in the program directory.

    Got rid of "PresentationParams" key.

    Added a new key called "Font", which can be set to e.g. '8.Courier'.

HELP file:
    Renamed default to "xvihelp.txt"; will look for it first in the current
    directory, then in the program directory.

XVINIT environment variable:
    Alpha-1 release misspelled this variable XVIINIT. It has been changed
    to XVINIT to match the XVI manual.

Fixed filename expansion of command line. (this may actually have been working
in alpha-1, but I broke it later).

Added File/Force menu entry (toggle) which changes the operation of most of
the entries in the File menu to force overwrites/edit loss, using the "!"
command modifier. Added shortcut prompt text to menu that changes with the
Force flag.

Added an about box for Help/Product Information.

Made mousebutton #3 (middle button) do a "." command after positioning to the
clicked spot. If not in NORMAL mode, it will issue an ESC to get into
NORMAL mode first.

Made show_error bring up a message box instead of writing on the status line.
I don't know if I like this, though.

Fixed problem where :n with split window was not updating status info. Similar
problems with :e and :rew remain, however.

Changed mnemonics on some File menu choices.

---------------------- Alpha 2 to Alpha 3 changes:

Fixed loss of font information (actually, failure to restore it).

Added use of SHIFT-ENTER key (means the same as ENTER, but I'm lazy when
typing braces <g>). This was more work than necessary (needed to add an
accelerator table!)

---------------------- Alpha 3 to Alpha 4 changes:

* Added use of the F1 key for help. I think this worked till I made SHIFT-ENTER
work.

* Made the help file (default "xvihelp.txt" in the program directory) settable
several ways, including:
    XVIHELP environment variable
    XVINIT="set helpfile=filename"
    xvihelp.txt in current directory
    xvihelp.txt in program directory
Don't ask why it's so involved.

* Fixed bug where non-existent .INI file caused bad row/column count.

* May have fixed trap situation when switching between buffers.

* Made Alt-Backspace key do a "u" command. (menu had worked OK).

* Added the one feature everyone wanted: window resizing with mouse!
Sub-windows are sized proportionally, but respect the minrows parameter.

* Made re-sizing keep the title bar from going off the top or bottom of the screen.

* Added separately settable cursor display for NORMAL, INSERT, and REPLACE mode.
I added three parameters for this: (here with their defaults)

    set cursor=0x04ff40             (abbreviation: cu)
    set cursorins=0x04ffff          (abbrev: ci)
    set cursorrepl=0x06ffff         (abbref: cr)

Unfortunately, when you display these, they will display in decimal. You
will probably want to enter them in hex; just use a leading "0x".

The defaults give a solid, flashing underline for NORMAL mode (cursor),
a solid, flashing block for INSERT mode (cursorins), and a flashing hollow
block for REPLACE mode (cursorrepl).

Here's what the numbers mean (for example, the default cursor setting):

    set cursor=0x04ff40

    the first byte (the 04) denotes the style. This is a bitmap, add the
    following:
        SOLID 0         (i.e. the default)
        HALFTONE 1
        FRAME   2       (hollow rectangle)
        FLASH   4
    So the 04 means that it's solid and flashing. Other styles of interest:
        06  flashing frame (default for REPLACE mode)
        02  non-flashing frame
        00  solid, non-flashing block

    The second byte (the ff) gives the width. The current setting of 0xff
    means the entire character width (whatever it is; it can change character
    by character for a proportional font). 0x80 would be half the width of the
    character (128/255).
    If you give it a value of 00, the system's border value will be used
    instead of a proportional width.

    The third (low-order) byte (the 40) gives the cursor height. This works
    just like the width byte.

    To get the same cursor I used to have (the flashing solid line between
    characters), use 0x0400ff for all three settings.

* Added mouse pointer changing. If it's over a status bar, the mouse pointer
is an arrow, otherwise it's a text bar (the I-beam).

* The name of the XVIPM.INI file has been changed to lower-case.
No it hasn't (sorry, Stefan)! I was just kidding <g>. Seems that the
OS/2 Profile API's always change the name to upper case. I didn't think
that this was important enough to go through the trouble and time of renaming
the ini file after every time we save the settings. Do you?

* Made the status lines stay the same color when you're typing on them.

* Close from the System menu (or alt-F4) now does the same thing that
File/Exit does (that is, a ":q" or a ":q!", depending on the Force setting).
This should do a better job of cleaning up the preserve files.

* Made the File Dialog box remember the last selected path. However, "File/Save As"
still doesn't have the current file name.

* Got rid of "File/Select All" menu choice. It did nothing, anyway.

* Added "summary.lst" to alpha distribution package. Docs still suck, of course.
Perhaps a Grand Unified Document is needed. Any volunteers?

* Added a feeble attempt at internationalization: the locale= parameter.
This uses the Borland locale stuff, which is seriously limited. I have included
LOCALE.BLL, which is their locale file, and should be put in the same directory
as the program. There are four locales supported, each with three code-pages.
You will have to experiment with them to find one that works OK.

    The locales are:
        de_DE   German
        fr_FR   French
        en_GB   English (Great Britain)
        en_US   English (US)
    The code-pages are:
        DOS437  English
        DOS850  Multilingual, Latin-1
        WIN1252 Windows, Multilingual.

So, for instance, you could do a "set locale=de_DE.DOS850" to get German, and
the DOS850 codepage.

This should make the "w" command, etc. work right, as well as the change-case
(~) command.

* There still is a bug with "dw" on the last word on the last line of the file.

* Fixed the bug where ":w filename" didn't change the current filename.

* Made double-click of button 1 do the same thing as "^]", that is, if it's on the
first letter of a word, it will look up the word in the tags file and try to
jump to it. This can give you a primitive hypertext capability.

* Actually, I didn't like the above, so now "^]" and the mouse double click
will work if they're anywhere on an identifier. They get the whole identifier.

* Made ~ (flip case) and ctrl-_ (change top bit) accept a count.

* Made ctrl-_ work without the SHIFT key.

* Made arrow keys return to the mode they were in (thanks, George!)

* Added a single scrollbar that issues cursor motions.
