xvi
===

xvi, a portable multi-file text editor
