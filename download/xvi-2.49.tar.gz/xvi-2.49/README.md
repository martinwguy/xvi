xvi
===

xvi, a portable multi-file text editor

See doc/summary.ms for an extended description.
See doc/source.ms for a guide to understanding/modifying the source code.

See the file INSTALL for a guide to compiling and installing it.
