xvi
===

xvi, a portable multi-file text editor

See the manual page, doc/xvi.1, for an extended description.
See doc/source.ms for a guide to understanding/modifying the source code.

See the file INSTALL for a guide to compiling and installing it.

Its web site is at http://martinwguy.github.io/xvi
